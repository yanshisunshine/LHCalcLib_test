/* Copyright 2013-2015 The MathWorks, Inc. */

#ifndef CodeInstrHostAppSvc_h
#define CodeInstrHostAppSvc_h

#include "tmwtypes.h"

static const boolean_T CODEINSTRHOSTAPPSVC_ERROR = 0;
static const boolean_T CODEINSTRHOSTAPPSVC_SUCCESS = 1;

#define CODEINSTR_RTIOSTREAM_BASED_SERVICE_ID 2

#endif

